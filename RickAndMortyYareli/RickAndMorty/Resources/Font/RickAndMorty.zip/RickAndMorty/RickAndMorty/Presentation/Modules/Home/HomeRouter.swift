//
//  HomeRouter.swift
//  RickAndMorty
//
//  Created by Yareli Arragan Muñoz on 18/9/24.
//

import Foundation

class HomeRouter {
    let viewController: HomeViewController
    
    init(viewController: HomeViewController) {
        self.viewController = viewController
    }
    
   /* func goToCharacterDetail(_ character:  Character) {
            let characterDetailViewController = CharacterDetailBuilder().build(character)
            viewController.navigationController?.pushViewController(characterDetailViewController, animated: true)*/
        
}
